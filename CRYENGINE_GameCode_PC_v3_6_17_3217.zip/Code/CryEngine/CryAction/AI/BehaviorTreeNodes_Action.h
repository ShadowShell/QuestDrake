// CryEngine Header File.
// Copyright (C), Crytek, 1999-2014.


#pragma once

namespace BehaviorTree { struct INodeFactory; }

void RegisterActionBehaviorTreeNodes(BehaviorTree::INodeFactory& factory);
