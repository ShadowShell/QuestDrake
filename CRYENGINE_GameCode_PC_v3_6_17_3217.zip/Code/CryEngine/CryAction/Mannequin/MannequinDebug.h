// CryEngine Header File.
// Copyright (C), Crytek, 1999-2014.


#ifndef __MANNEQUIN_DEBUG__H__
#define __MANNEQUIN_DEBUG__H__

namespace mannequin
{
	namespace debug
	{
		void RegisterCommands();
	}
}

#endif